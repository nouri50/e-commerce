<?php
echo '<h2>Notre futur page d\'accueil pour notre boutique</h2>';
